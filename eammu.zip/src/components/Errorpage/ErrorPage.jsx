

const ErrorPage = () => {
    return (
        <div>
             <h1 className="text-center text-6xl font-bold mt-[254px]">Sorry,Your Connection Is Lost,Please Chack Your Internet Connection</h1>
        </div>
    );
};

export default ErrorPage;